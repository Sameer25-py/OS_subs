#ifndef PART_1
#define PART_1

void initializeP1(int numFloors, int maxNumPeople);
void *goingFromToP1(void *);
void startP1();
void *start_simul();

#endif
